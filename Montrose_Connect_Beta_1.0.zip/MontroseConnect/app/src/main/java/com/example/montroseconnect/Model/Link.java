package com.example.montroseconnect.Model;

//Author: Nolan Barajas 1/8/2020

public class Link {
    private int image_id;
    private String name;
    private String url;

    public Link(int image_id, String name, String url) {
        this.image_id = image_id;
        this.name = name;
        this.url = url;
    }

    public int getImage_id() {
        return image_id;
    }

    public void setImage_id(int image_id) {
        this.image_id = image_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;}

    public void setUrl(String url) {
        this.url = url; }
}
