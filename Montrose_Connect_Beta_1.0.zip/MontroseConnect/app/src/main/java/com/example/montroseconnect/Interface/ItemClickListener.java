package com.example.montroseconnect.Interface;

//Author: Nolan Barajas 1/8/2020

import android.view.View;

public interface ItemClickListener {

    void onClick(View view, int position);
}
