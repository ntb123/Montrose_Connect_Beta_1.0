package com.example.montroseconnect;

//Author: Nolan Barajas 1/8/2020

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.montroseconnect.Adapter.RecyclerViewAdapter;
import com.example.montroseconnect.Model.Link;

import java.util.ArrayList;
import java.util.List;

public class Links extends AppCompatActivity {

    List<Link> linkList = new ArrayList<>();
    RecyclerView.LayoutManager layoutManager;
    RecyclerView recyclerView;
    RecyclerViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_links);


        initData();

        //Add adapter and layout manager to custom recycler view
        recyclerView = (RecyclerView) findViewById(R.id.list_ex);
        adapter = new RecyclerViewAdapter(linkList, getBaseContext());
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

    }

    //Initialize links and logos
    private void initData() {
        linkList.add(new Link(R.drawable.epa, "EPA", "https://www.epa.gov/emc"));
        linkList.add(new Link(R.drawable.netsuite, "NetSuite",
                "https://system.netsuite.com/pages/customerlogin.jsp"));
        linkList.add(new Link(R.drawable.concur, "Concur", "https://www.concur.com/"));
        linkList.add(new Link(R.drawable.dayforce, "Dayforce",
                "https://www.dayforcehcm.com/mydayforce/login.aspx"));
    }
}
