package com.example.montroseconnect;

//Author: Nolan Barajas 1/8/2020

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class THERCalculator extends AppCompatActivity {

    EditText param_1, param_2;
    Button ther_btn;
    TextView ther_ans;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thercalculator);

        param_1 = findViewById(R.id.ther_param_1);
        param_2 = findViewById(R.id.ther_param_2);
        ther_btn = findViewById(R.id.ther_btn);
        ther_ans = findViewById(R.id.ther_ans);

        ther_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String param_1_ = param_1.getText().toString();
                String param_2_ = param_2.getText().toString();
                param_1.setText("");
                param_2.setText("");
                double first = Double.parseDouble(param_1_);
                double second = Double.parseDouble(param_2_);
                double ans = (first * 44.1 * second) / 385300000;
                ther_ans.setText(Double.toString(ans));
            }
        });
    }
}
