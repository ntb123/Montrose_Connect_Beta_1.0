package com.example.montroseconnect;

//Author: Nolan Barajas 1/8/2020

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import static java.lang.Math.PI;

public class ASLCalculator extends AppCompatActivity {

    Button asl_btn;
    EditText asl_param;
    TextView asl_ans;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aslcalculator);

        asl_param = findViewById(R.id.asl_param);
        asl_btn = findViewById(R.id.asl_btn);
        asl_ans = findViewById(R.id.asl_ans);

        asl_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String param = asl_param.getText().toString();
                asl_param.setText("");
                double ans = Double.parseDouble(param);
                ans = ans / (24);
                ans = ans * ans;
                ans = ans * PI;
                asl_ans.setText(Double.toString(ans));
            }
        });
    }
}
