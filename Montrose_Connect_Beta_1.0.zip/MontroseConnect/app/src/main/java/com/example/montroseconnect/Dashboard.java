package com.example.montroseconnect;

//Author: Nolan Barajas 1/8/2020

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.net.Uri;

public class Dashboard extends AppCompatActivity {

    ImageView news, locations, links, contacts, calendar, chatroom, asl_calc, ther_calc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        news = findViewById(R.id.news_link);
        locations = findViewById(R.id.loc_link);
        links = findViewById(R.id.web_link);
        contacts = findViewById(R.id.contacts);
        calendar = findViewById(R.id.calendar);
        chatroom = findViewById(R.id.chatroom);
        asl_calc = findViewById(R.id.asl_calc);
        ther_calc = findViewById(R.id.ther_calc);

        news.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://montrose-env.com/news-events/"));
                startActivity(intent);
            }
        });

        locations.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://montrose-env.com/contactus/?location=Elk-Grove-Village-Illinois"));
                startActivity(intent);
            }
        });

        links.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this, Links.class);
                startActivity(intent);
            }
        });

        contacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this, Contacts.class);
                startActivity(intent);
            }
        });

        calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this, Calendar.class);
                startActivity(intent);
            }
        });

        chatroom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this, Chatroom.class);
                startActivity(intent);
            }
        });

        asl_calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this, ASLCalculator.class);
                startActivity(intent);
            }
        });

        ther_calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this, THERCalculator.class);
                startActivity(intent);
            }
        });
    }
}
